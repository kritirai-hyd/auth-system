import Register from "@/components/RegisterForm";


export default function Home() {
  return (
<>
<Register />
</>
  );
}
