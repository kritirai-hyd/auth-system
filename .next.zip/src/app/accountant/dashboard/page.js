import Accountant from "@/components/Accountant";


export default async function AccountantDashboard() {


  return (
    <main>

<Accountant />
    </main>
  );
}
