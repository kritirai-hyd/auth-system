(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_assets_css_4a2ce97e._.css",
  "static/chunks/_bf0c76dd._.js"
],
    source: "dynamic"
});
