(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f18e1e19._.js",
  "static/chunks/[root-of-the-server]__b008cb71._.css"
],
    source: "dynamic"
});
