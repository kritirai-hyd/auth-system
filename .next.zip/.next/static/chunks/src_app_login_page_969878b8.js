(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d96b0d6b._.js",
  "static/chunks/src_assets_css_4a2ce97e._.css"
],
    source: "dynamic"
});
